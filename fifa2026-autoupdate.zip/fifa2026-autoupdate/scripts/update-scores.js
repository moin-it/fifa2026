#!/usr/bin/env node
/**
 * update-scores.js
 * ------------------------------------------------------------------
 * FIFA World Cup 2026 — auto score updater
 *
 * Fetches live/finished match results from football-data.org (primary)
 * and TheSportsDB (fallback), maps them onto this app's internal match
 * IDs (same team-name logic as index.html), and writes scores.json.
 *
 * Run by .github/workflows/update-scores.yml on a schedule.
 * Designed to be safe to run repeatedly: if nothing changed, it makes
 * no commit (the workflow checks `git diff` before committing).
 * ------------------------------------------------------------------
 */

const fs = require('fs');
const path = require('path');

const SCORES_PATH = path.join(__dirname, '..', 'scores.json');
const FOOTBALL_DATA_TOKEN = process.env.FOOTBALL_DATA_TOKEN || '';

// ============================================================
// MATCH LIST — keep in sync with MATCHES in index.html
// (only team1/team2/id are needed here; TBD = knockout match
// not yet resolved, skipped until bracket is known)
// ============================================================
const MATCHES = [
  {id:1,team1:"Mexico",team2:"South Africa"},
  {id:2,team1:"South Korea",team2:"Czechia"},
  {id:3,team1:"Canada",team2:"Bosnia & Herzegovina"},
  {id:4,team1:"United States",team2:"Paraguay"},
  {id:5,team1:"Qatar",team2:"Switzerland"},
  {id:6,team1:"Brazil",team2:"Morocco"},
  {id:7,team1:"Haiti",team2:"Scotland"},
  {id:8,team1:"Australia",team2:"Türkiye"},
  {id:9,team1:"Germany",team2:"Curaçao"},
  {id:10,team1:"Netherlands",team2:"Japan"},
  {id:11,team1:"Ivory Coast",team2:"Ecuador"},
  {id:12,team1:"Sweden",team2:"Tunisia"},
  {id:13,team1:"Spain",team2:"Cape Verde"},
  {id:14,team1:"Belgium",team2:"Egypt"},
  {id:15,team1:"Saudi Arabia",team2:"Uruguay"},
  {id:16,team1:"Iran",team2:"New Zealand"},
  {id:17,team1:"France",team2:"Senegal"},
  {id:18,team1:"Iraq",team2:"Norway"},
  {id:19,team1:"Argentina",team2:"Algeria"},
  {id:20,team1:"Austria",team2:"Jordan"},
  {id:21,team1:"Portugal",team2:"DR Congo"},
  {id:22,team1:"England",team2:"Croatia"},
  {id:23,team1:"Ghana",team2:"Panama"},
  {id:24,team1:"Uzbekistan",team2:"Colombia"},
  {id:25,team1:"Czechia",team2:"South Africa"},
  {id:26,team1:"Switzerland",team2:"Bosnia & Herzegovina"},
  {id:27,team1:"Canada",team2:"Qatar"},
  {id:28,team1:"Mexico",team2:"South Korea"},
  {id:29,team1:"United States",team2:"Australia"},
  {id:30,team1:"Scotland",team2:"Morocco"},
  {id:31,team1:"Brazil",team2:"Haiti"},
  {id:32,team1:"Türkiye",team2:"Paraguay"},
  {id:33,team1:"Netherlands",team2:"Sweden"},
  {id:34,team1:"Germany",team2:"Ivory Coast"},
  {id:35,team1:"Ecuador",team2:"Curaçao"},
  {id:36,team1:"Tunisia",team2:"Japan"},
  {id:37,team1:"Spain",team2:"Saudi Arabia"},
  {id:38,team1:"Belgium",team2:"Iran"},
  {id:39,team1:"Uruguay",team2:"Cape Verde"},
  {id:40,team1:"New Zealand",team2:"Egypt"},
  {id:41,team1:"Argentina",team2:"Austria"},
  {id:42,team1:"France",team2:"Iraq"},
  {id:43,team1:"Norway",team2:"Senegal"},
  {id:44,team1:"Jordan",team2:"Algeria"},
  {id:45,team1:"Portugal",team2:"Uzbekistan"},
  {id:46,team1:"England",team2:"Ghana"},
  {id:47,team1:"Panama",team2:"Croatia"},
  {id:48,team1:"Colombia",team2:"DR Congo"},
  {id:49,team1:"Switzerland",team2:"Canada"},
  {id:50,team1:"Bosnia & Herzegovina",team2:"Qatar"},
  {id:51,team1:"Scotland",team2:"Brazil"},
  {id:52,team1:"Morocco",team2:"Haiti"},
  {id:53,team1:"Czechia",team2:"Mexico"},
  {id:54,team1:"South Africa",team2:"South Korea"},
  {id:55,team1:"Curaçao",team2:"Ivory Coast"},
  {id:56,team1:"Ecuador",team2:"Germany"},
  {id:57,team1:"Japan",team2:"Sweden"},
  {id:58,team1:"Tunisia",team2:"Netherlands"},
  {id:59,team1:"Türkiye",team2:"United States"},
  {id:60,team1:"Paraguay",team2:"Australia"},
  {id:61,team1:"Norway",team2:"France"},
  {id:62,team1:"Senegal",team2:"Iraq"},
  {id:63,team1:"Cape Verde",team2:"Saudi Arabia"},
  {id:64,team1:"Uruguay",team2:"Spain"},
  {id:65,team1:"Egypt",team2:"Iran"},
  {id:66,team1:"New Zealand",team2:"Belgium"},
  {id:67,team1:"Panama",team2:"England"},
  {id:68,team1:"Croatia",team2:"Ghana"},
  {id:69,team1:"Colombia",team2:"Portugal"},
  {id:70,team1:"DR Congo",team2:"Uzbekistan"},
  {id:71,team1:"Algeria",team2:"Austria"},
  {id:72,team1:"Jordan",team2:"Argentina"},
  // 73-104 are knockout rounds, TBD until bracket resolves —
  // intentionally omitted; add team1/team2 here once known,
  // or rely on the date+venue fallback matcher below.
];

// Same normalization table as the client (index.html TEAM_NAME_MAP),
// mapping various API spellings -> this app's canonical team names.
const TEAM_NAME_MAP = {
  'Mexico': 'Mexico', 'South Africa': 'South Africa',
  'Korea Republic': 'South Korea', 'Czech Republic': 'Czechia', 'Czechia': 'Czechia',
  'Canada': 'Canada', 'Bosnia and Herzegovina': 'Bosnia & Herzegovina',
  'Bosnia-Herzegovina': 'Bosnia & Herzegovina', 'USA': 'United States',
  'United States': 'United States', 'United States of America': 'United States',
  'Paraguay': 'Paraguay', 'Qatar': 'Qatar', 'Switzerland': 'Switzerland',
  'Brazil': 'Brazil', 'Morocco': 'Morocco', 'Haiti': 'Haiti', 'Scotland': 'Scotland',
  'Australia': 'Australia', 'Turkey': 'Türkiye', 'Türkiye': 'Türkiye',
  'Germany': 'Germany', 'Curaçao': 'Curaçao', 'Curacao': 'Curaçao',
  'Netherlands': 'Netherlands', 'The Netherlands': 'Netherlands', 'Japan': 'Japan',
  'Ivory Coast': 'Ivory Coast', "Côte d'Ivoire": 'Ivory Coast', "Cote d'Ivoire": 'Ivory Coast',
  'Ecuador': 'Ecuador', 'Sweden': 'Sweden', 'Tunisia': 'Tunisia',
  'Spain': 'Spain', 'Cape Verde': 'Cape Verde', 'Cabo Verde': 'Cape Verde',
  'Belgium': 'Belgium', 'Egypt': 'Egypt', 'Saudi Arabia': 'Saudi Arabia',
  'Uruguay': 'Uruguay', 'Iran': 'Iran', 'IR Iran': 'Iran', 'New Zealand': 'New Zealand',
  'France': 'France', 'Senegal': 'Senegal', 'Iraq': 'Iraq', 'Norway': 'Norway',
  'Argentina': 'Argentina', 'Algeria': 'Algeria', 'Austria': 'Austria', 'Jordan': 'Jordan',
  'Portugal': 'Portugal', 'DR Congo': 'DR Congo', 'Congo DR': 'DR Congo',
  'England': 'England', 'Croatia': 'Croatia', 'Ghana': 'Ghana', 'Panama': 'Panama',
  'Uzbekistan': 'Uzbekistan', 'Colombia': 'Colombia'
};

function buildTeamMatchMap() {
  const map = {};
  MATCHES.forEach(m => {
    map[`${m.team1}||${m.team2}`] = m.id;
    map[`${m.team2}||${m.team1}`] = m.id;
  });
  return map;
}

function statusToAppStatus(apiStatus) {
  // Normalize various API status strings to what index.html expects.
  if (['FINISHED'].includes(apiStatus)) return 'FINISHED';
  if (['IN_PLAY', 'PAUSED', 'LIVE', '1H', '2H', 'HT'].includes(apiStatus)) return 'LIVE';
  return apiStatus || 'SCHEDULED';
}

// ============================================================
// SOURCE 1: football-data.org
// ============================================================
async function fetchFromFootballData() {
  const url = 'https://api.football-data.org/v4/competitions/WC/matches?status=FINISHED,LIVE,IN_PLAY,PAUSED';
  const headers = {};
  if (FOOTBALL_DATA_TOKEN) headers['X-Auth-Token'] = FOOTBALL_DATA_TOKEN;

  const res = await fetch(url, { headers, signal: AbortSignal.timeout(15000) });
  if (!res.ok) throw new Error(`football-data.org HTTP ${res.status}`);
  const data = await res.json();
  if (!data.matches) throw new Error('football-data.org: no matches field');

  const teamMap = buildTeamMatchMap();
  const out = {};

  data.matches.forEach(m => {
    const t1 = TEAM_NAME_MAP[m.homeTeam?.name] || m.homeTeam?.name;
    const t2 = TEAM_NAME_MAP[m.awayTeam?.name] || m.awayTeam?.name;
    const matchId = teamMap[`${t1}||${t2}`];
    if (!matchId) return; // unmapped (likely a knockout TBD match)

    const g1 = m.score?.fullTime?.home ?? m.score?.regularTime?.home;
    const g2 = m.score?.fullTime?.away ?? m.score?.regularTime?.away;
    if (g1 === null || g1 === undefined || g2 === null || g2 === undefined) return;

    const entry = {
      score: `${g1} – ${g2}`,
      status: statusToAppStatus(m.status),
      source: 'football-data'
    };

    const p1 = m.score?.penalties?.home;
    const p2 = m.score?.penalties?.away;
    if (p1 !== null && p1 !== undefined && p2 !== null && p2 !== undefined) {
      entry.pens = `${p1} – ${p2}`;
    }

    out[matchId] = entry;
  });

  return out;
}

// ============================================================
// SOURCE 2: TheSportsDB (fallback)
// ============================================================
async function fetchFromSportsDb() {
  const url = 'https://www.thesportsdb.com/api/v1/json/3/eventsseason.php?id=4436&s=2026';
  const res = await fetch(url, { signal: AbortSignal.timeout(15000) });
  if (!res.ok) throw new Error(`thesportsdb HTTP ${res.status}`);
  const data = await res.json();
  if (!data.events) throw new Error('thesportsdb: no events field');

  const teamMap = buildTeamMatchMap();
  const out = {};

  data.events.forEach(ev => {
    if (ev.intHomeScore === null && ev.intAwayScore === null) return;
    const t1 = TEAM_NAME_MAP[ev.strHomeTeam] || ev.strHomeTeam;
    const t2 = TEAM_NAME_MAP[ev.strAwayTeam] || ev.strAwayTeam;
    const matchId = teamMap[`${t1}||${t2}`];
    if (!matchId) return;

    const g1 = parseInt(ev.intHomeScore, 10);
    const g2 = parseInt(ev.intAwayScore, 10);
    if (isNaN(g1) || isNaN(g2)) return;

    out[matchId] = {
      score: `${g1} – ${g2}`,
      status: statusToAppStatus(ev.strStatus),
      source: 'thesportsdb'
    };
  });

  return out;
}

// ============================================================
// MAIN
// ============================================================
async function main() {
  let existing = { scores: {} };
  try {
    existing = JSON.parse(fs.readFileSync(SCORES_PATH, 'utf8'));
  } catch (e) {
    console.log('[update-scores] no existing scores.json, starting fresh');
  }

  let fresh = {};
  let usedSource = null;

  try {
    fresh = await fetchFromFootballData();
    usedSource = 'football-data.org';
    console.log(`[update-scores] football-data.org returned ${Object.keys(fresh).length} mapped matches`);
  } catch (e) {
    console.log('[update-scores] football-data.org failed:', e.message);
  }

  if (Object.keys(fresh).length === 0) {
    try {
      fresh = await fetchFromSportsDb();
      usedSource = 'thesportsdb';
      console.log(`[update-scores] thesportsdb returned ${Object.keys(fresh).length} mapped matches`);
    } catch (e) {
      console.log('[update-scores] thesportsdb failed:', e.message);
    }
  }

  if (Object.keys(fresh).length === 0) {
    console.log('[update-scores] no source returned data — leaving scores.json untouched');
    process.exit(0);
  }

  // Merge: API data overwrites previous API-sourced entries, but never
  // touches entries someone added by hand (source: "manual") — so you
  // can still hand-correct a score and the bot won't stomp on it.
  const merged = { ...existing.scores };
  Object.entries(fresh).forEach(([id, entry]) => {
    if (merged[id]?.source === 'manual') return; // respect manual overrides
    merged[id] = entry;
  });

  const result = {
    scores: merged,
    lastUpdated: new Date().toISOString(),
    note: 'Auto-updated by GitHub Actions (' + usedSource + '). Add "source":"manual" entries by hand to override — the bot will not touch those.'
  };

  fs.writeFileSync(SCORES_PATH, JSON.stringify(result, null, 2) + '\n', 'utf8');
  console.log('[update-scores] scores.json written, total entries:', Object.keys(merged).length);
}

main().catch(err => {
  console.error('[update-scores] fatal error:', err);
  process.exit(1);
});
